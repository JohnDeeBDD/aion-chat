<?php
/*
Plugin Name: Aion Chat
Plugin URI: https://aion.garden
Description: The Singularity is here.
Version: 6
Author: johndee
Author URI: https://generalchicken.guru
License: Copyright(C) 2024, generalchicken.guru . All rights reserved. THIS IS NOT FREE SOFTWARE.
*/

namespace AionChat;

//die("AionChat");

global $AionChatProtocal;
$AionChatProtocal = "remote_node";

require_once(plugin_dir_path(__FILE__) . 'src/AionChat/autoloader.php');

global $Servers;
$Servers = new Servers();

\add_filter('comment_flood_filter', '__return_false');
\add_filter('duplicate_comment_id', '__return_false');
\add_filter('wp_is_application_passwords_available', '__return_true');
\add_action('admin_menu', '\AionChat\Plugin::do_create_admin_page');
\add_action('comment_post', '\AionChat\Comment::do_on_WordPress_action_comment_post', 10, 1);
\add_action('init', '\AionChat\User::add_aion_role');
Conversation::enable_aion_conversation_cpt();
ExampleConversation::enablePublishExampleConversations();
Functions::enableFunctionCall();
ActionButtonManager::enable_custom_comment_buttons();

\register_activation_hook(__FILE__, '\AionChat\ActivationHook::do_activation_hook');
require_once(plugin_dir_path(__FILE__) . 'src/update-checker/plugin-update-checker.php');
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;
$myUpdateChecker = PucFactory::buildUpdateChecker(
    'https://aion.garden/wp-content/uploads/details.json',
    __FILE__,
    'aion-chat'
);

\add_action('wp_enqueue_scripts', function () {
    if (\is_singular("aion-conversation")) {

        \wp_register_script(
            'aion-conversation-cpt',
            \plugin_dir_url(__FILE__) . '/src/AionChat/aion-conversation-cpt.js', // here is the JS file
            ['jquery', 'wp-api', 'heartbeat'],
            '1.0',
            true
        );
        \wp_enqueue_script('aion-conversation-cpt');
        \wp_localize_script( 'aion-conversation-cpt', 'aion_chat_nonce',
            array(
                'nonce' => \wp_create_nonce("aion-chat-action"),
            )
        );

    }
});


\add_filter( 'is_protected_meta', '__return_false' );
