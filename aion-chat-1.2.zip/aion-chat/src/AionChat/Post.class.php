<?php

namespace AionChat;

class Post{

    public static function parseIonConversationTitle($string){

    }

}