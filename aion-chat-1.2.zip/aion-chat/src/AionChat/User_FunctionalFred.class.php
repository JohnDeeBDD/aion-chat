<?php

namespace AionChat;

class FunctionalFred{



}