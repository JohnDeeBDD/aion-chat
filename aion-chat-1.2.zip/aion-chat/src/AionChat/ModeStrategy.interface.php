<?php

interface ModeStrategy{

}