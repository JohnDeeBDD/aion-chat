<?php

namespace AionChat;

class Task{ //a.k.a. "Gherkin /scenario"

    //A task can be thought of ideally as a specific Gherkin scenario with data
    //It should be matched to a known scenario outline that has a positive outcome
    //If there is no known Gherkin scenario, the task must be refactored

    //Status - data associated with the task, progress

    //Given - the current state of the world

    //Objective - the desired state of the world that does not exist

    //Assigned dispatch - who and when was assigned to this task who is master, user, Aion, deamon

    //type instant | dispatched

}