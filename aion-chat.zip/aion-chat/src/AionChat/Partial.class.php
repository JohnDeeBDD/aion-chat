<?php

namespace AionChat;

class Partial{

    public function initializeHomepage(){}
    public function houseKeeping(){}
    public function phoneHome(){}

}