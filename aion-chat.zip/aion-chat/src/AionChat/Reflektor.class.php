<?php

namespace AionChat;

class Reflektor{

    //The reflektor catches messages on one site, and sends them up or down

    public static function enable($Aion, $remote_connection_url, $protocol){}
    public static function sendUp(Prompt $Prompt){}
    private static function record_dispatch(Prompt $Prompt){}
    private static function record_return(Prompt $Prompt){}

}