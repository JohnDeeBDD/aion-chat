<?php

namespace AionChat;

class Skill{

    //A skill is a WordPress plugin that requires the Skill object here
    public $type;

    // PHP method
    // API call
    // WordPress method
    // JS method
    // Codeception Cept
    // Codeception method

    public string $method_name;

}